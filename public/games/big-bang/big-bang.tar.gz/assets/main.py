import asyncio
import os
from pathlib import Path

# Import explícito permite ao pygbag detectar e instalar pygame-ce antes dos módulos locais.
import pygame  # noqa: F401

from src.jogo import executar_jogo
from src.web import notificar


async def main():
    # Recursos relativos funcionam tanto pelo terminal quanto no filesystem do pygbag.
    os.chdir(Path(__file__).resolve().parent)
    try:
        await executar_jogo()
        notificar("exited")
    except Exception as error:
        notificar("error", str(error))
        raise


if __name__ == "__main__":
    asyncio.run(main())
