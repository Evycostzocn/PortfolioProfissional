"""Ponte opcional: Python desktop não depende das APIs JavaScript do pygbag."""
import sys


def notificar(estado, detalhe=""):
    if sys.platform == "emscripten":
        import platform
        platform.window.bigBangStatus(estado, detalhe)
